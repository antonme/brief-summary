# Privacy Policy

Please carefully read this privacy policy documenting all of the information
that is collected by this browser extension.

## 1. Information we collect

Nothing.

## 2. Cookies

Nope.
