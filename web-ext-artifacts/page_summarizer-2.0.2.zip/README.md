# Page Summarizer

Chrome extension for summarizing news articles with LLMs. Supports gpt4/claude/perplexity, based on https://github.com/sysread/page-summarizer
